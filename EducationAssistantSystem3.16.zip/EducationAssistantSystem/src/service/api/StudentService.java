package service.api;

public interface StudentService {
	public boolean login(String username,String password);
}
