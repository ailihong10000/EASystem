package service.api;

public interface AdminService {
	public boolean login(String username,String password);
}
