package service.api;

public interface TeacherService {
	public boolean login(String username,String password);
 
}
