package action.base;

public class BaseAction {

}
