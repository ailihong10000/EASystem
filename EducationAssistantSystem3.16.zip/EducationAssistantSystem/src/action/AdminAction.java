package action;

import com.opensymphony.xwork2.ActionSupport;

public class AdminAction extends ActionSupport {
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return SUCCESS;
	}

}
